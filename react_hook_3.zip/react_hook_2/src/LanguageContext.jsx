import { createContext, useContext, useMemo, useState } from 'react';

const dict = {
  ru: {
    title: 'Менеджер задач', newTask: 'Новая задача', add: 'Добавить',
    all: 'Все', active: 'Активные', done: 'Готовые',
    total: 'Всего', completed: 'выполнено', search: 'Поиск по задачам (нажми /)',
    dark: 'Тёмная', light: 'Светлая', edit: 'Редактирование',
    renamePrompt: 'Новый текст задачи:', langBtn: 'English',
    reset: 'Сбросить', updating: 'обновляем…',
    clearDone: 'Удалить выполненные', addMany: '+2000 тестовых', clearAll: 'Удалить все',
  },
  en: {
    title: 'Task Manager', newTask: 'New task', add: 'Add',
    all: 'All', active: 'Active', done: 'Done',
    total: 'Total', completed: 'completed', search: 'Search tasks (press /)',
    dark: 'Dark', light: 'Light', edit: 'Edit',
    renamePrompt: 'New task text:', langBtn: 'Русский',
    reset: 'Reset', updating: 'updating…',
    clearDone: 'Delete completed', addMany: '+2000 test tasks', clearAll: 'Delete all',
  },
};

const LanguageContext = createContext(null);

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState('ru');
  const value = useMemo(() => ({ lang, setLang, t: dict[lang] }), [lang]);
  return <LanguageContext value={value}>{children}</LanguageContext>;
}

export function useLanguage() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage нужно вызывать внутри LanguageProvider');
  return ctx;
}